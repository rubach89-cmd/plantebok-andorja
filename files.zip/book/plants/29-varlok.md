# Vårløk/Pipeløk (_Allium fistulosum_) – løkvekst

- Hardførhet: God; flerårig/stauderot med kontinuerlig løkstilker
- Vekstform: Buskete klumper; hul løkstilker
- Bruk: Mild løksmak; rå i salat, garnityr
- Plassering: Sol; drenert jord

## Dyrking på Andørja (Igeland)
- Såing: Forkultiver tidlig vår eller så direkte under duk i mai.
- Jord: Moldrik, veldrenert; pH 6,2–6,8.
- Vedlikehold: Del tuer annethvert år for å holde jevn produksjon.

## Skadedyr/sykdom
- Løkflue/løkmøll: Fiberduk; rotasjon.

## Høsting
- Vår–sommer; klipp fortløpende; kan overvintre og gi tidlig vårhøst.