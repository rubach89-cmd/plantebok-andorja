# Tyttebær (_Vaccinium vitis-idaea_) – bær

- Hardførhet: Svært hardfør; egnet i H6–H7
- Vekstform: Lav, eviggrønn busk
- Bruk: Syltetøy, saft, tørking; lagringsdyktig
- Plassering: Sol til halvskygge; sur jord (pH 4,5–5,5)

## Dyrking på Andørja (Igeland)
- Jord: Sur, lett og humusrik; bruk torv/skogbunnjord/kompostert furunålsstrø; unngå kalk.
- Fukt: Jevn fukt; god drenering.
- Planting: 30–40 cm mellom planter; danner etter hvert matter.
- Vind: Tåler vind; lav høyde gir naturlig le.

## Sorter
- ‘Koralle’ (kultivert, jevn avling)
- ‘Red Pearl’ (store bær, god smak)

## Skadedyr/sykdom
- Få problemer; fugl kan ta bær – bruk nett ved modning.

## Høsting/bruk
- Sensommer/høst; plukk jevnlig.
- Bruk: Klassisk tyttebærsyltetøy; tørkede bær til turblanding.