# Ruccola (_Eruca sativa_) – bladgrønnsak

- Hardførhet: God; foretrekker kjølig
- Vekstform: Ettårig; hurtig
- Bruk: Salater, pizza, pesto
- Plassering: Sol til halvskygge; vår/høst

## Dyrking på Andørja (Igeland)
- Såing: April–mai og august; suksessiv hver 2. uke.
- Jord: Lett, jevn fukt.
- Beskyttelse: Duk mot jordlopper.

## Sorter
- ‘Rocket’ (vanlig)
- Villruccola (Diplotaxis) for mer pepper (dyrkes likt, men tregere).

## Høsting
- Klipp blad; høst smått for best smak.