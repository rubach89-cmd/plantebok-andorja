# Hageblåbær (_Vaccinium corymbosum_) – bær

- Hardførhet: God med riktig jord; velg hardføre sorter
- Vekstform: Busk (1–1,5 m)
- Bruk: Store bær; fersk, frysing, baking
- Plassering: Sol til halvskygge; sur jord (pH 4,5–5,5)

## Dyrking på Andørja (Igeland)
- Jord: Sur og luftet; bland torv, bark, løvkompost; hevede surjordsbed.
- Fukt: Jevn fukt; unngå kalk og høyt pH.
- Planting: 1–1,2 m mellom; to ulike sorter gir bedre avling.

## Sorter
- ‘Northblue’, ‘Northcountry’ (hardføre)
- ‘Patriot’ (stor bær, relativt hardfør)

## Skadedyr/sykdom
- Fugl: Nett.
- Klorete bær ved tørke: Jevn vanning, mulch.

## Høsting
- Juli–august; plukk flere ganger etter modning.