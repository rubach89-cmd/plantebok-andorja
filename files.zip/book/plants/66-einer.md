# Einer (_Juniperus communis_) – krydder/nytte

- Hardførhet: Svært hardfør; tåler kystvind og noe salt
- Vekstform: Eviggrønn busk/tre
- Bruk: Einerbær som krydder; røking; te av nåler
- Plassering: Sol; godt drenert, gjerne sandig/grusblandet jord

## Dyrking på Andørja (Igeland)
- Planting: Vår/høst; unngå vannmettet jord.
- Vedlikehold: Minimal; formklipp ved behov.
- Naturhensyn: Dyrk kulturplanter i hage; ikke overhøst villbestand.

## Bruk og forsiktighet
- Krydder: Knuste bær til vilt, fisk og sylting.
- Røking: Kvist/nåler gir aroma.
- Forsiktighet: Unngå overdrevent inntak ved graviditet eller nyreproblemer.

## Høsting
- Sen høst; bare modne, blå bær (toårig modning).