# Kinakål (_Brassica rapa_ ssp. pekinensis) – bladkål

- Hardførhet: God i kjølig; best som høstavling
- Vekstform: Avlangt hode
- Bruk: Salat, wok, kimchi
- Plassering: Sol; jevn fukt og le

## Dyrking på Andørja (Igeland)
- Såing: Juli–august for høst; vårsåing kan bolte.
- Jord: Moldrik; pH 6,5–6,8.
- Beskyttelse: Nett mot kålskadedyr; lavtunnel ved vind.

## Sorter
- ‘Michihili’ (avlang)
- ‘Monument’ (kompakt)

## Skadedyr/sykdom
- Kålflue/kålsommerfugl: Nett.
- Indre råte ved stress: Hold jevn fukt.

## Høsting
- Sept–okt; lagre kort tid kjølig; bruk til kimchi.