# Løpstikke/Lovage (_Levisticum officinale_) – urt

- Hardførhet: Svært hardfør staude
- Vekstform: Stor urt (1,5–2 m)
- Bruk: Kraftig smak til supper og gryter
- Plassering: Sol til halvskygge; vindstøtte

## Dyrking på Andørja (Igeland)
- Jord: Moldrik og fuktig; dyp rot.
- Etablering: Plant vår; del rot hvert 3.–4. år for fornyelse.
- Vedlikehold: Klipp ned senhøst; mulch vinter.

## Skadedyr/sykdom
- Få problemer; vindstøtte anbefales.

## Høsting
- Blad og stilker fra vår til sen sommer; bruk sparsomt (sterk smak).