# Søtmispel/Amelanchier (_Amelanchier_ spp.) – bær/hekk

- Hardførhet: Svært hardfør; tåler H6–H7
- Vekstform: Busk/lite tre; hvite vårblomster
- Bruk: Spiselige bær (juni/beg. juli), saft, tørking; flott hekk/vindbryter
- Plassering: Sol til halvskygge; drenert jord

## Dyrking på Andørja (Igeland)
- Jord: Moldrik, veldrenert; tåler noe tørke/vind.
- Planting: 1,5–2,5 m avstand for hekk; beskjær lett for struktur.
- Mikroklima: God vindtoleranse; egnet som mellomsjikt i levegg.

## Skadedyr/sykdom
- Få problemer; fugl tar bær – nett ved behov.

## Høsting/bruk
- Tidlig sommer; bær med mild, søt smak.
- Bruk: Tørkede bær, syltetøy, blanding med aronia/solbær.