# Rips (_Ribes rubrum_) – bærbusk

- Hardførhet: Svært hardfør; egnet for kystklima
- Vekstform: Flerårig busk
- Bruk: Saft, gelé, syltetøy
- Plassering: Sol til halvskygge; tåler vind

## Dyrking på Andørja (Igeland)
- Jord: Moldrik, jevn fukt; pH 6–6,5.
- Planting: 1,5–2 m mellom busker; sett noe dypt.
- Beskjæring: Fjern eldste greiner (3–4 år) for å forynge.

## Sorter
- ‘Red Lake’: Jevn avling
- ‘Jonkheer van Tets’: Tidlig, god smak

## Skadedyr/sykdom
- Meldugg: Velg robuste sorter; luftsirkulasjon.
- Fugler: Nett under modning.

## Høsting og bruk
- Juli–aug; hele klaser. Safting/gelé er klassisk.