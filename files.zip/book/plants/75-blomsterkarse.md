# Blomsterkarse/Nasturtium (_Tropaeolum majus_) – blomster/blad (ettårig)

- Hardførhet: Ettårig; trives i kjølige somre med le
- Vekstform: Krypende/klatrende; spiselige blomster og blad
- Bruk: Salater, pynt, lett pepperaktig smak; kapers-erstatning av frø
- Plassering: Sol; vindbeskyttelse; kasser/kanter

## Dyrking på Andørja (Igeland)
- Såing: Mai inne; utplant i juni når frostfaren er over; eller direkte under duk.
- Jord: Moderat næring; for mye N gir mye blad og få blomster.
- Vind: Bruk le/duk for pene blomster og hel blad.

## Skadedyr/sykdom
- Få; se etter snegler; hold gangveier tørre og ryddige.

## Høsting/bruk
- Blomster og unge blad gjennom sommeren; frø kan syltes («kapers»).
- God pollinatorplante; egnet som kant og for biologisk mangfold.