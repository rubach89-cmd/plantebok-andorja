# Karve (_Carum carvi_) – urt

- Hardførhet: Svært hardfør; toårig
- Vekstform: Rosett første år; blomster og frø andre år
- Bruk: Frø til bakst/ost; unge blad som grønnsak
- Plassering: Sol; veldrenert jord

## Dyrking på Andørja (Igeland)
- Såing: Vår; tynnes lett.
- Vedlikehold: Lite krav; robust i vind.
- Høsting: Frø andre år; klipp og tørk skjermene; rens for frø.

## Skadedyr/sykdom
- Få problemer; selvsåing kan forekomme – kontroller ved fjerning av frøstander.