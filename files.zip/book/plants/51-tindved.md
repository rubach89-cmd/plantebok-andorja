# Tindved (_Hippophae rhamnoides_) – bær/skjerm

- Hardførhet: Svært hardfør; tåler vind og salt
- Vekstform: Busk (2–4 m), tornet; nitrogenfikserende
- Bruk: C-vitaminrike bær; saft, sirup; vind- og saltskjerm
- Plassering: Sol; sandig, veldrenert jord; tåler mager jord

## Dyrking på Andørja (Igeland)
- Hann + hunn: Krever begge for bær; 1 hann for 4–6 hunnplanter.
- Avstand: 2–3 m; egnet i ytre sjikt av levegg nær sjø.
- Jord: Tåler salt og sand; unngå næringssmett – trives mager.

## Skadedyr/sykdom
- Få; beskytt mot uønsket spredning med kontrollert beskjæring.

## Høsting/bruk
- Sept–okt; bær er snerpende – bruk pressing; filtrer frø/skal.
- Naturhensyn: Unngå spredning utenfor hage; respekter lokale naturverdier.