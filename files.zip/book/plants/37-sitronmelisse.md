# Sitronmelisse (_Melissa officinalis_) – urt

- Hardførhet: Marginal i H6–H7; dyrkes ofte som ettårig eller med sterk vinterbeskyttelse
- Vekstform: Flerårig urt; aromatisk sitronsmak
- Bruk: Te, dessert, krydder
- Plassering: Sol til halvskygge; lun plass; god drenering

## Dyrking på Andørja (Igeland)
- Etablering: Plant i opphøyde, lune bed; gjerne potte som tas under tak om vinteren.
- Vinter: Tykt dekke av løv/kvist; snødekke hjelper; risiko for utvintring.
- Vanning: Jevn fukt uten vannlogging.

## Skadedyr/sykdom
- Få; overvåk for råte i våt vinterjord.

## Høsting
- Klipp unge skudd; tørk forsiktig for te.