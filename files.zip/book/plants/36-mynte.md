# Mynte (_Mentha_ spp.) – urt

- Hardførhet: God; flerårig med kraftig vekst
- Vekstform: Krypende, sprer seg med jordstengler
- Bruk: Te, dessert, krydder
- Plassering: Sol til halvskygge; fuktig, moldrik jord

## Dyrking på Andørja (Igeland)
- Kontainer: Dyrk i avgrenset bed eller potter for å hindre spredning.
- Vanning: Jevn fukt; mulch.
- Overvintring: Som regel problemfri; beskjær ned senhøst.

## Sorter
- Peppermynte (_Mentha × piperita_)
- Grønnmynte (_Mentha spicata_)
- Appelmynte (_Mentha suaveolens_)

## Skadedyr/sykdom
- Rust og meldugg ved fuktig, tett vekst: Tynn og sikr luft.

## Høsting
- Klipp toppskudd; tørk i skygge for vinterte.