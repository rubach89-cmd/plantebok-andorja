# Bokhvete (_Fagopyrum esculentum_) – pseudokorn

- Hardførhet: Følsom for frost; dyrkes i varmeste del av sesongen
- Vekstform: Hurtigvekst; blomstrer og setter frø midtsommer
- Bruk: Mel (pannekaker, brød), grønnmasse som dekkevekst
- Plassering: Sol; varm og drenert jord

## Dyrking på Andørja (Igeland)
- Såing: Juni–juli når natten er mild; 1–2 cm dypt; bredså.
- Vind: Moderat le; planten er skjør – unngå sterk vind.
- Bruk som dekkevekst: Kveler ugras; tilfør organisk masse.

## Høsting/bruk
- Frø: Høst i slutten av sesongen; forvent moderat avling i nord.
- Mel: Mal i liten kvern; bland med hvete/bygg for brød.