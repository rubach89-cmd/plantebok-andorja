# Rogn (_Sorbus aucuparia_) – frukt til gelé/nytte

- Hardførhet: Svært hardfør; egnet som leplante og pryd/nytte
- Vekstform: Lite tre/busk
- Bruk: Bær til gelé/vin (etter frost); tidlig pollen for insekter
- Plassering: Sol til halvskygge; drenert jord

## Dyrking på Andørja (Igeland)
- Planting: Vår/høst; brukes som leplante i kantsoner.
- Vedlikehold: Lett beskjæring; tåler vind.
- Sorter: Pryd-/spisevarianter med lavere bitterhet (sjekk norske planteskoler).

## Høsting/bruk
- Etter første frost (reduserer bitterhet); bland med eple erstattes her med søtmispel/aronia til gelé.